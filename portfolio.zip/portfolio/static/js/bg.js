$(document).ready(function(){

var circle1 = document.getElementById('circle-1');
var circle2 = document.getElementById('circle-2');
var circle3 = document.getElementById('circle-3');
var circle4 = document.getElementById('circle-4');
var circle5 = document.getElementById('circle-5');
var circle6 = document.getElementById('circle-6');
var circle7 = document.getElementById('circle-7');
var circle8 = document.getElementById('circle-8');
var circle9 = document.getElementById('circle-9');
var circle10 = document.getElementById('circle-10');
var circle11 = document.getElementById('circle-11');
var circle12 = document.getElementById('circle-12');
var circle13 = document.getElementById('circle-13');
var circle14 = document.getElementById('circle-14');
var body = document.body;
var channel2 = document.getElementById('channel-2');
var channel3 = document.getElementById('channel-3');
var channel4 = document.getElementById('channel-4');
var channel5 = document.getElementById('channel-5');
var channel6 = document.getElementById('channel-6');
var channel7 = document.getElementById('channel-7');
var channel8 = document.getElementById('channel-8');
var channel9 = document.getElementById('channel-9');
var channel10 = document.getElementById('channel-10');
var channel11 = document.getElementById('channel-11');
var channel12 = document.getElementById('channel-12');
var channel13 = document.getElementById('channel-13');
var channel14 = document.getElementById('channel-14');
var channel15 = document.getElementById('channel-15');
var channel16 = document.getElementById('channel-16');
var channel17 = document.getElementById('channel-17');
var channel18 = document.getElementById('channel-18');
var channel19 = document.getElementById('channel-19');
var channel20 = document.getElementById('channel-20');
var channel21 = document.getElementById('channel-21');
var channel22 = document.getElementById('channel-22');
var hide = document.getElementById('hide');

circle1.onmouseover = function() {
	body.className = 'circle1';
}

circle1.onmouseout = function() {
	body.className = '';
}

circle2.onmouseover = function() {
	document.getElementById('channel2').className = 'channel-2';
}

circle2.onmouseout = function() {
	document.getElementById('channel2').className = '';
}

circle3.onmouseover = function() {
	body.className = 'circle3';
}

circle3.onmouseout = function() {
	body.className = '';
}
circle4.onmouseover = function() {
	body.className = 'circle4';
}

circle4.onmouseout = function() {
	body.className = '';
}

circle5.onmouseover = function() {
	body.className = 'circle5';
}

circle5.onmouseout = function() {
	body.className = '';
}

circle6.onmouseover = function() {
	document.getElementById('channel3').className = 'channel-3';
}

circle6.onmouseout = function() {
	document.getElementById('channel3').className = '';
}
circle7.onmouseover = function() {
	body.className = 'circle7';
}

circle7.onmouseout = function() {
	body.className = '';
}

circle8.onmouseover = function() {
	body.className = 'circle8';
}

circle8.onmouseout = function() {
	body.className = '';
}

circle9.onmouseover = function() {
	body.className = 'circle9';
}

circle9.onmouseout = function() {
	body.className = '';
}

circle10.onmouseover = function() {
	body.className = 'circle10';
}

circle10.onmouseout = function() {
	body.className = '';
}

circle11.onmouseover = function() {
	body.className = 'circle11';
}

circle11.onmouseout = function() {
	body.className = '';
}
circle12.onmouseover = function() {
	body.className = 'circle12';
}

circle12.onmouseout = function() {
	body.className = '';
}
circle13.onmouseover = function() {
	body.className = 'circle13';
}

circle13.onmouseout = function() {
	body.className = '';
}
circle14.onmouseover = function() {
	body.className = 'circle14';
}

circle14.onmouseout = function() {
	body.className = '';
}


});